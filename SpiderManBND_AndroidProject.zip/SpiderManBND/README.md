# Spider-Man: Brand New Day Web Player (Android)

Open this folder in Android Studio (Koala or newer), let Gradle sync, press Run.
Min Android 10 (API 29). Kotlin + Jetpack Compose + Media3 ExoPlayer.

Library
- DOWNLOADS ON scans the main Downloads folder and every subfolder at any depth (any folder names).
- MUSIC ON does the same for the Music folder.
- + FOLDER picks any other folder; it and all its subfolders are scanned. Remembered between launches.
- SYNC rescans, FORGET clears picked folders and removed tracks, X removes a track or folder.
  (Android does not let apps pick the Downloads root in the folder picker, so Downloads has its own toggle.)

Player
- Tempo / pitch regulator 0.50x-2.00x in 0.05 steps, presets, PITCH LINK on/off
- -10s / +10s, prev / next, loop off / single / all, shuffle, web-strand seek bar
- Background playback with a notification / lock-screen player
