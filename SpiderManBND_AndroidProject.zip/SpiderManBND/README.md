# Spider-Man: Brand New Day Web Player (Android)

Kotlin + Jetpack Compose + Media3. Min Android 10.

Get the APK
- Android Studio: open this folder, let Gradle sync, then Build > Build Bundle(s)/APK(s) > Build APK(s).
  The file lands in app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and install it.
- No Android Studio: put this folder in a GitHub repo and push it. The Build APK workflow
  (.github/workflows/build-apk.yml) builds it; download the APK from the Actions run's Artifacts.

Tabs
- PLAYER: spinning web record, wheel controls, web-strand seek, tempo/pitch, loop, shuffle
- LIBRARY: Downloads (all subfolders), Music, and any folder you add; SYNC, FORGET, X to remove
- ONLINE: search and trending from Audius (free, open music network). Streams use the same player,
  so tempo/pitch, effects and the notification all work. Needs internet.
