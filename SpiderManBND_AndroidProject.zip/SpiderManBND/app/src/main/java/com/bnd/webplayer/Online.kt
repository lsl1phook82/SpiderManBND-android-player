package com.bnd.webplayer

import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Audius: free, open music network. Search and trending need no login.
 * Optional: put a free API key from https://api.audius.co/plans in API_KEY for higher rate limits.
 * Results are returned as Track objects whose uri is the stream link, so they play through the same player.
 */
object Audius {
    private const val HOST = "https://api.audius.co"
    private const val APP = "BNDWebPlayer"
    private const val API_KEY = ""

    fun trending(): List<Track> = fetch("$HOST/v1/tracks/trending?limit=40&app_name=$APP")

    fun search(q: String): List<Track> =
        fetch("$HOST/v1/tracks/search?query=${URLEncoder.encode(q, "UTF-8")}&limit=40&app_name=$APP")

    private fun fetch(url: String): List<Track> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 12000
        c.setRequestProperty("Accept", "application/json")
        if (API_KEY.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $API_KEY")
        val body = try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
        val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
        val out = ArrayList<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optBoolean("is_streamable", true)) continue
            val id = o.optString("id")
            if (id.isEmpty()) continue
            val artist = o.optJSONObject("user")?.optString("name") ?: "Unknown artist"
            out += Track(
                Uri.parse("$HOST/v1/tracks/$id/stream?app_name=$APP"),
                o.optString("title", "Untitled"), artist, id, 0L
            )
        }
        return out
    }
}
