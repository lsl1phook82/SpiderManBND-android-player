package com.bnd.webplayer

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.sqrt

/** Pass-through audio processor that measures loudness so the web can react to the music. */
class LevelMeter : BaseAudioProcessor() {
    @Volatile var level = 0f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n == 0) return
        val dup = inputBuffer.duplicate().order(ByteOrder.nativeOrder())
        var sum = 0.0
        var count = 0
        while (dup.remaining() >= 2) {
            val s = dup.short.toInt()
            sum += (s * s).toDouble()
            count++
            if (dup.remaining() >= 16) dup.position(dup.position() + 14)   // skip ahead: cheap sampling
        }
        if (count > 0) level = min(1f, (sqrt(sum / count) / 32768.0).toFloat() * 3.4f)
        val out = replaceOutputBuffer(n)
        out.put(inputBuffer)
        out.flip()
    }

    override fun onFlush() { level = 0f }
}

object Hub {
    val meter = LevelMeter()
    private var exo: ExoPlayer? = null

    fun player(ctx: Context): ExoPlayer = exo ?: build(ctx.applicationContext).also { exo = it }

    private fun build(app: Context): ExoPlayer {
        val renderers = object : DefaultRenderersFactory(app) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf(meter))
                .build()
        }
        return ExoPlayer.Builder(app, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
    }
}

/** Keeps music playing with a lock-screen / notification player when the app is in the background. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, Hub.player(this)).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}
