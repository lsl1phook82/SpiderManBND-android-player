package com.bnd.webplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

// ---- BRAND NEW DAY palette: suit black, suit red, web white, spidey-sense blue ----
val Ink = Color(0xFF05060C)
val Navy = Color(0xFF0A1330)
val Panel = Color(0xFF0D1426)
val Panel2 = Color(0xFF151D3A)
val Red = Color(0xFFE5192B)
val RedHot = Color(0xFFFF4B5C)
val RedD = Color(0xFF7A0C16)
val Blue = Color(0xFF1E5BFF)
val Cyan = Color(0xFF35D6FF)
val Gold = Color(0xFFFFD21F)
val Snow = Color(0xFFF2F4FF)
val Dim = Color(0xFF8E9BC4)

/** Shared animation state: clock, music loudness, beat pulse and disc spin. */
class Fx {
    var t by mutableFloatStateOf(0f)
    var level by mutableFloatStateOf(0f)
    var pulse by mutableFloatStateOf(0f)
    var spin by mutableFloatStateOf(0f)
}

@Composable
fun rememberFx(playing: Boolean): Fx {
    val fx = remember { Fx() }
    val pl by rememberUpdatedState(playing)
    LaunchedEffect(Unit) {
        var last = 0L
        var avg = 0f
        var lastBeat = 0f
        while (true) {
            withFrameNanos { ns ->
                if (last == 0L) last = ns
                val dt = ((ns - last) / 1_000_000_000f).coerceAtMost(0.1f)
                last = ns
                fx.t += dt
                val target = if (pl) Hub.meter.level else 0f
                fx.level += (target - fx.level) * (if (target > fx.level) 0.5f else 0.12f)
                avg = avg * 0.96f + fx.level * 0.04f
                if (pl && fx.level > avg * 1.3f + 0.07f && fx.t - lastBeat > 0.28f) {
                    fx.pulse = 1f; lastBeat = fx.t
                }
                fx.pulse = (fx.pulse - dt * 2.4f).coerceAtLeast(0f)
                if (pl) fx.spin = (fx.spin + dt * (40f + 120f * fx.level)) % 360f
            }
        }
    }
    return fx
}

// ---------------------------------------------------------------- drawing helpers

/** A spider web sector: radial threads plus sagging rings. a0..a1 in radians (full circle = 0..2PI). */
fun DrawScope.webSector(
    anchor: Offset, a0: Float, a1: Float, maxR: Float, segs: Int, rings: Int,
    spokeColor: Color, ringColor: Color, w: Float, sag: Float = 0.22f
) {
    fun pt(k: Int, r: Float): Offset {
        val a = a0 + (a1 - a0) * k / segs
        return Offset(anchor.x + cos(a) * r, anchor.y + sin(a) * r)
    }
    for (k in 0..segs) drawLine(spokeColor, anchor, pt(k, maxR), strokeWidth = w)
    for (ri in 1..rings) {
        val r = maxR * ri / rings
        for (k in 0 until segs) {
            val p0 = pt(k, r); val p1 = pt(k + 1, r)
            val mx = (p0.x + p1.x) / 2f; val my = (p0.y + p1.y) / 2f
            val cx = mx + (anchor.x - mx) * sag; val cy = my + (anchor.y - my) * sag
            val path = Path().apply { moveTo(p0.x, p0.y); quadraticBezierTo(cx, cy, p1.x, p1.y) }
            drawPath(path, ringColor, style = Stroke(w))
        }
    }
}

fun DrawScope.spider(c: Offset, s: Float, body: Color, mark: Color) {
    val cy = c.y - 0.2f * s
    val legs = listOf(
        floatArrayOf(.22f, -.15f, .70f, -.80f, 1.0f, -.55f),
        floatArrayOf(.28f, -.04f, .95f, -.30f, 1.25f, .0f),
        floatArrayOf(.28f, .08f, .95f, .38f, 1.15f, .75f),
        floatArrayOf(.20f, .20f, .60f, .85f, .75f, 1.2f)
    )
    for (m in listOf(1f, -1f)) for (l in legs) {
        val p = Path().apply {
            moveTo(c.x + m * l[0] * s, cy + l[1] * s)
            lineTo(c.x + m * l[2] * s, cy + l[3] * s)
            lineTo(c.x + m * l[4] * s, cy + l[5] * s)
        }
        drawPath(p, body, style = Stroke(s * 0.1f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    drawOval(body, Offset(c.x - s * .24f, cy - s * .05f), Size(s * .48f, s * .72f))
    drawOval(body, Offset(c.x - s * .14f, cy - s * .38f), Size(s * .28f, s * .32f))
    val hg = Path().apply {
        moveTo(c.x - s * .10f, cy + s * .12f); lineTo(c.x + s * .10f, cy + s * .12f); lineTo(c.x, cy + s * .30f); close()
        moveTo(c.x, cy + s * .30f); lineTo(c.x - s * .10f, cy + s * .48f); lineTo(c.x + s * .10f, cy + s * .48f); close()
    }
    drawPath(hg, mark)
}

// ---------------------------------------------------------------- full-screen web background

@Composable
fun WebBackground(fx: Fx) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(Ink, Navy, Ink)))

        // comic halftone dots fading out from the bottom-left corner
        val step = 26.dp.toPx()
        val diag = hypot(w, h)
        var gy = 0
        var y = h
        while (y > -step) {
            var x = if (gy % 2 == 0) 0f else step / 2f
            while (x < w + step) {
                val d = hypot(x, h - y) / diag
                val r = (1f - d * 1.7f).coerceAtLeast(0f) * step * 0.38f * (1f + fx.level * 0.6f)
                if (r > 0.8f) drawCircle(Red.copy(alpha = 0.17f), r, Offset(x, y))
                x += step
            }
            y -= step * 0.86f; gy++
        }

        // two corner webs that sway and flash with the beat
        val glow = 0.16f + fx.level * 0.35f
        val ringCol = lerp(Color.White, RedHot, fx.pulse * 0.85f).copy(alpha = glow)
        val spokeCol = Color.White.copy(alpha = 0.12f + fx.level * 0.2f)
        val sway = sin(fx.t * 0.7f) * 0.03f
        val maxR = min(w * 1.15f, h * 0.55f)
        webSector(Offset(w, 0f), (PI / 2).toFloat() + sway, PI.toFloat() - sway, maxR, 6, 8, spokeCol, ringCol, 1.2.dp.toPx())
        webSector(Offset(0f, h), (-PI / 2).toFloat() + sway, 0f - sway, maxR * 0.8f, 5, 7, spokeCol, ringCol, 1.2.dp.toPx())

        // beat shockwave travelling along the web
        if (fx.pulse > 0.02f) {
            val r = maxR * (1.05f - fx.pulse)
            webSector(Offset(w, 0f), (PI / 2).toFloat(), PI.toFloat(), r, 6, 1,
                Color.Transparent, RedHot.copy(alpha = fx.pulse * 0.9f), 3.dp.toPx(), 0.18f)
        }
    }
}

// ---------------------------------------------------------------- spinning spider record

@Composable
fun SpiderDisc(fx: Fx, dia: Dp) {
    Box(Modifier.size(dia), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val p = r * (1f + fx.level * 0.06f)
            drawCircle(
                Brush.radialGradient(listOf(Red.copy(alpha = 0.45f + fx.level * 0.4f), Color.Transparent), center, p), p
            )
            drawCircle(
                Brush.sweepGradient(listOf(Red, Blue, Cyan, Red), center),
                r * 0.9f * (1f + fx.level * 0.03f), style = Stroke(3.dp.toPx())
            )
        }
        Canvas(Modifier.fillMaxSize(0.84f).graphicsLayer { rotationZ = fx.spin }) {
            val r = this.size.minDimension / 2f
            drawCircle(Color(0xFF080B16), r)
            for (i in 1..9) drawCircle(Color.White.copy(alpha = 0.05f), r * (0.4f + i * 0.06f), style = Stroke(1.dp.toPx()))
            drawCircle(
                Brush.sweepGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.12f), Color.Transparent,
                        Color.Transparent, Color.White.copy(alpha = 0.12f), Color.Transparent), center
                ), r
            )
            webSector(center, 0f, (2 * PI).toFloat(), r * 0.98f, 8, 4,
                Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.10f), 1.dp.toPx(), 0.12f)
            drawCircle(Brush.radialGradient(listOf(RedHot, Red, RedD), center, r * 0.38f), r * 0.38f)
            spider(center, r * 0.25f, Ink, RedHot)
            drawCircle(Ink, r * 0.03f)
        }
    }
}

// ---------------------------------------------------------------- skyline equalizer

@Composable
fun Equalizer(fx: Fx, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(58.dp)) {
        val n = 30
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        val brush = Brush.verticalGradient(listOf(Cyan, Red), 0f, size.height)
        for (i in 0 until n) {
            val shape = 0.45f + 0.55f * abs(sin(fx.t * 5f + i * 0.9f)) * (0.6f + 0.4f * cos(i * 0.3f + fx.t * 2f))
            val hh = (size.height * (0.07f + 0.93f * fx.level * shape)).coerceAtLeast(3.dp.toPx())
            val x = i * (bw + gap)
            drawRoundRect(brush, Offset(x, size.height - hh), Size(bw, hh), androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
            drawRect(Snow.copy(alpha = 0.9f), Offset(x, size.height - hh), Size(bw, 2.dp.toPx()))
            // lit windows
            var wy = size.height - hh + 6.dp.toPx()
            while (wy < size.height - 4.dp.toPx()) {
                if (((i * 7 + (wy / 6.dp.toPx()).toInt() * 3) % 4) == 0) {
                    drawRect(Ink.copy(alpha = 0.55f), Offset(x + bw * 0.3f, wy), Size(bw * 0.4f, 2.dp.toPx()))
                }
                wy += 7.dp.toPx()
            }
        }
    }
}

// ---------------------------------------------------------------- web-strand seek bar with a spider

@Composable
fun WebSeek(progress: Float, onSeek: (Float) -> Unit, fx: Fx) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val onSeekNow by rememberUpdatedState(onSeek)
    val shown = drag ?: progress
    Canvas(
        Modifier.fillMaxWidth().height(50.dp)
            .pointerInput(Unit) { detectTapGestures { o -> onSeekNow((o.x / size.width).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { onSeekNow(it) }; drag = null },
                    onDragCancel = { drag = null }
                ) { change, _ -> drag = (change.position.x / size.width).coerceIn(0f, 1f) }
            }
    ) {
        val pad = 14.dp.toPx()
        val x0 = pad; val x1 = size.width - pad
        val cy = size.height / 2f
        val sx = x0 + (x1 - x0) * shown
        // cross threads
        var x = x0
        while (x <= x1) {
            drawLine(Color.White.copy(alpha = 0.16f), Offset(x, cy - 7.dp.toPx()), Offset(x, cy + 7.dp.toPx()), 1.dp.toPx())
            x += 16.dp.toPx()
        }
        drawLine(Color.White.copy(alpha = 0.35f), Offset(x0, cy), Offset(x1, cy), 2.dp.toPx(), StrokeCap.Round)
        drawLine(Red.copy(alpha = 0.35f + fx.level * 0.4f), Offset(x0, cy), Offset(sx, cy), 8.dp.toPx(), StrokeCap.Round)
        drawLine(RedHot, Offset(x0, cy), Offset(sx, cy), 3.dp.toPx(), StrokeCap.Round)
        // the spider hangs on the strand
        drawLine(Snow.copy(alpha = 0.7f), Offset(sx, cy), Offset(sx, cy - 4.dp.toPx()), 1.dp.toPx())
        spider(Offset(sx, cy), 9.dp.toPx(), Snow, Red)
    }
}

// ---------------------------------------------------------------- one-shot overlays

@Composable
fun WebShot(tick: Int) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(tick) {
        if (tick > 0) {
            p.snapTo(0f)
            p.animateTo(1f, tween(180, easing = LinearEasing))
            p.animateTo(2f, tween(450))
        }
    }
    if (p.value > 0f && p.value < 2f) {
        Canvas(Modifier.fillMaxSize()) {
            val from = Offset(size.width, 0f)
            val to = Offset(size.width * 0.45f, size.height * 0.30f)
            val shot = p.value.coerceAtMost(1f)
            val fade = if (p.value > 1f) 2f - p.value else 1f
            val tip = from + (to - from) * shot
            drawLine(Snow.copy(alpha = fade), from, tip, 3.dp.toPx(), StrokeCap.Round)
            if (p.value > 1f) {
                val rr = 14.dp.toPx() * (0.4f + (p.value - 1f) * 3f)
                for (k in 0 until 12) {
                    val a = (2 * PI * k / 12).toFloat()
                    drawLine(Snow.copy(alpha = fade), tip,
                        Offset(tip.x + cos(a) * rr, tip.y + sin(a) * rr), 1.5.dp.toPx(), StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
fun ComicBurst(tick: Int, word: String, modifier: Modifier = Modifier) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(tick) {
        if (tick > 0) {
            a.snapTo(0f)
            a.animateTo(1f, tween(140))
            delay(520)
            a.animateTo(0f, tween(260))
        }
    }
    if (a.value > 0.01f) {
        Box(
            modifier.size(230.dp).graphicsLayer {
                val s = 0.4f + 0.8f * a.value
                scaleX = s; scaleY = s; alpha = a.value.coerceAtMost(1f); rotationZ = -8f
            },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center
                val ro = this.size.minDimension / 2f * 0.96f
                val path = Path()
                val pts = 18
                for (i in 0 until pts * 2) {
                    val r = if (i % 2 == 0) ro else ro * 0.62f
                    val ang = (PI * i / pts).toFloat()
                    val px = c.x + cos(ang) * r; val py = c.y + sin(ang) * r
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                drawPath(path, Ink.copy(alpha = 0.8f), style = androidx.compose.ui.graphics.drawscope.Fill)
                drawPath(Path().apply { addPath(path, Offset(-5.dp.toPx(), -5.dp.toPx())) }, Gold)
                drawPath(Path().apply { addPath(path, Offset(-5.dp.toPx(), -5.dp.toPx())) }, Red, style = Stroke(5.dp.toPx(), join = StrokeJoin.Round))
            }
            Text(
                word, color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center, maxLines = 2, modifier = Modifier.padding(horizontal = 46.dp)
            )
        }
    }
}
