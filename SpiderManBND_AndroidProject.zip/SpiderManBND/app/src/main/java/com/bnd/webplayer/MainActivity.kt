package com.bnd.webplayer

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale
import kotlin.math.PI

private val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    private val vm: Vm by viewModels()

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.rescan() }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            vm.addFolder(uri)
        }
    }

    private var controller: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        try { startService(Intent(this, PlaybackService::class.java)) } catch (_: Exception) {}
        // Connecting a controller binds the service, which is what makes the media notification appear.
        try {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controller = MediaController.Builder(this, token).buildAsync()
        } catch (_: Exception) {}

        val need = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { if (vm.tracks.isEmpty()) vm.rescan() }
        else permissions.launch(missing.toTypedArray())

        setContent { BndApp(vm) { folderPicker.launch(null) } }
    }

    override fun onDestroy() {
        controller?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

private fun f2(v: Float) = String.format(Locale.US, "%.2f", v)
private fun mmss(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return String.format(Locale.US, "%02d:%02d", s / 60, s % 60) }

// ================================================================= root

@Composable
fun BndApp(vm: Vm, onPickFolder: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Ink, surface = Panel)) {
        val fx = rememberFx(vm.playing)
        var tab by remember { mutableIntStateOf(0) }
        Box(Modifier.fillMaxSize().background(Ink)) {
            WebBackground(fx)
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Header(vm, fx)
                Box(Modifier.weight(1f)) {
                    when (tab) { 0 -> PlayerTab(vm, fx); 1 -> LibraryTab(vm, onPickFolder); else -> OnlineTab(vm) }
                }
                if (tab != 0 && vm.index >= 0) MiniBar(vm)
                TabBar(tab) { tab = it }
            }
            WebShot(vm.burstTick)
            ComicBurst(vm.burstTick, vm.burstWord, Modifier.align(Alignment.Center))
        }
    }
}

// ================================================================= pieces

@Composable
private fun GlitchLayer(text: String, sp: TextUnit, color: Color, dx: Float, fx: Fx) {
    Text(
        text, color = color, fontSize = sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.SansSerif,
        letterSpacing = 1.sp, maxLines = 1,
        modifier = Modifier.graphicsLayer { translationX = dx * (1f + fx.pulse * 3f) }
    )
}

@Composable
fun GlitchText(text: String, sp: TextUnit, fx: Fx) {
    Box {
        GlitchLayer(text, sp, Cyan.copy(alpha = 0.75f), -2.5f, fx)
        GlitchLayer(text, sp, Red.copy(alpha = 0.9f), 2.5f, fx)
        GlitchLayer(text, sp, Snow, 0f, fx)
    }
}

@Composable
fun Header(vm: Vm, fx: Fx) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(46.dp).graphicsLayer { rotationZ = fx.spin * 0.2f }) {
            val r = this.size.minDimension / 2f
            drawCircle(Brush.sweepGradient(listOf(Red, Blue, Red), center), r - 1.dp.toPx(), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
            webSector(center, 0f, (2 * PI).toFloat(), r * 0.9f, 8, 3, Color.White.copy(alpha = 0.25f), Color.White.copy(alpha = 0.25f), 1.dp.toPx(), 0.15f)
            spider(center, r * 0.42f, Red, Ink)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            GlitchText("SPIDER-MAN", 26.sp, fx)
            Text("BRAND NEW DAY  //  WEB PLAYER", color = Cyan, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun TabBar(tab: Int, onTab: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Ink.copy(alpha = 0.85f))) {
        listOf("PLAYER", "LIBRARY", "ONLINE").forEachIndexed { i, label ->
            Box(
                Modifier.weight(1f).clickable { onTab(i) }.padding(vertical = 14.dp)
                    .underline(if (tab == i) Red else Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (tab == i) Snow else Dim, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
            }
        }
    }
}

private fun Modifier.underline(c: Color) = this.drawBehind {
    drawRect(c, Offset(0f, size.height - 3.dp.toPx()), androidx.compose.ui.geometry.Size(size.width, 3.dp.toPx()))
}

@Composable
fun WebButton(text: String, accent: Color, modifier: Modifier = Modifier, filled: Boolean = false, onClick: () -> Unit) {
    val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
    val hf = LocalHapticFeedback.current
    Box(
        modifier.clip(shape)
            .background(if (filled) accent.copy(alpha = 0.9f) else Panel2.copy(alpha = 0.75f))
            .border(1.5.dp, accent, shape)
            .clickable { hf.performHapticFeedback(HapticFeedbackType.LongPress); onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (filled) Snow else accent, fontFamily = Mono, fontWeight = FontWeight.Bold,
            fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun PanelBox(accent: Color, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = CutCornerShape(topStart = 20.dp, bottomEnd = 20.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(Panel.copy(alpha = 0.92f), Ink.copy(alpha = 0.92f))))
            .border(1.5.dp, Brush.linearGradient(listOf(accent, Blue.copy(alpha = 0.5f))), shape)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, content = content
    )
}

enum class Ic { PLAY, PAUSE, PREV, NEXT }

@Composable
fun Glyph(ic: Ic, color: Color, dia: Dp = 28.dp) {
    Canvas(Modifier.size(dia)) {
        val w = size.width; val h = size.height
        when (ic) {
            Ic.PLAY -> drawPath(Path().apply { moveTo(w * .28f, h * .15f); lineTo(w * .88f, h * .5f); lineTo(w * .28f, h * .85f); close() }, color)
            Ic.PAUSE -> { drawRect(color, Offset(w * .22f, h * .15f), androidx.compose.ui.geometry.Size(w * .22f, h * .7f))
                drawRect(color, Offset(w * .56f, h * .15f), androidx.compose.ui.geometry.Size(w * .22f, h * .7f)) }
            Ic.PREV -> { drawRect(color, Offset(w * .12f, h * .15f), androidx.compose.ui.geometry.Size(w * .13f, h * .7f))
                drawPath(Path().apply { moveTo(w * .9f, h * .15f); lineTo(w * .32f, h * .5f); lineTo(w * .9f, h * .85f); close() }, color) }
            Ic.NEXT -> { drawRect(color, Offset(w * .75f, h * .15f), androidx.compose.ui.geometry.Size(w * .13f, h * .7f))
                drawPath(Path().apply { moveTo(w * .1f, h * .15f); lineTo(w * .68f, h * .5f); lineTo(w * .1f, h * .85f); close() }, color) }
        }
    }
}

// ================================================================= player tab

@Composable
fun PlayerTab(vm: Vm, fx: Fx) {
    val t = vm.queue.getOrNull(vm.index)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        PanelBox(Red) {
            SpiderDisc(fx, 214.dp)
            Spacer(Modifier.height(10.dp))
            Text(t ?: "NO TRACK LOADED", color = Snow, fontSize = 19.sp, fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(t?.folder ?: "OPEN LIBRARY OR ONLINE", color = Dim, fontFamily = Mono, fontSize = 11.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(
                if (t != null) "TRACK %02d OF %02d".format(vm.index + 1, vm.queue.size) else "0 TRACKS",
                color = Cyan, fontFamily = Mono, fontSize = 12.sp
            )
            Text("SPEED: ${f2(vm.speed)}x | PITCH: ${f2(if (vm.pitchLink) vm.speed else 1f)}x",
                color = Gold, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Equalizer(fx)
        }

        // time + web seek
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(mmss(vm.posMs), color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(mmss(vm.durMs), color = Dim, fontFamily = Mono, fontSize = 15.sp)
            }
            WebSeek(if (vm.durMs > 0) (vm.posMs.toFloat() / vm.durMs).coerceIn(0f, 1f) else 0f, vm::seekFraction, fx)
        }

        WebWheel(vm, fx)

        // tempo / pitch regulator
        PanelBox(Gold) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("TEMPO / PITCH REGULATOR", color = Dim, fontFamily = Mono, fontSize = 12.sp)
                Text("${f2(vm.speed)}x", color = Gold, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            }
            Slider(
                value = vm.speed, onValueChange = { vm.changeSpeed(it) }, valueRange = 0.5f..2f, steps = 29,
                colors = SliderDefaults.colors(
                    thumbColor = Red, activeTrackColor = Red, inactiveTrackColor = Panel2,
                    activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                WebButton("-0.05x", RedHot) { vm.changeSpeed(vm.speed - 0.05f) }
                WebButton("+0.05x", Cyan) { vm.changeSpeed(vm.speed + 0.05f) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { p ->
                    WebButton(f2(p) + "x", if (vm.speed == p) Gold else Dim, Modifier.weight(1f), vm.speed == p) { vm.changeSpeed(p) }
                }
            }
            Spacer(Modifier.height(8.dp))
            WebButton(if (vm.pitchLink) "PITCH LINK ON: SPEED + PITCH" else "PITCH LINK OFF: TEMPO ONLY",
                Cyan, Modifier.fillMaxWidth()) { vm.togglePitchLink() }
        }

        // modes
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val loop = listOf("OFF", "SINGLE", "ALL")[vm.repeat.coerceIn(0, 2)]
            WebButton("LOOP: $loop", if (vm.repeat == 0) Dim else Cyan, Modifier.weight(1f), vm.repeat != 0) { vm.cycleRepeat() }
            WebButton(if (vm.shuffle) "SHUFFLE: ON" else "SHUFFLE: OFF", if (vm.shuffle) Red else Dim, Modifier.weight(1f), vm.shuffle) { vm.toggleShuffle() }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun WebWheel(vm: Vm, fx: Fx) {
    val hf = LocalHapticFeedback.current
    Box(Modifier.size(286.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            drawCircle(Brush.radialGradient(listOf(Panel2, Ink), center, r), r)
            webSector(center, 0f, (2 * PI).toFloat(), r * 0.97f, 12, 5,
                Color.White.copy(alpha = 0.10f + fx.level * 0.2f),
                lerp(Color.White, RedHot, fx.pulse).copy(alpha = 0.12f + fx.pulse * 0.5f), 1.dp.toPx(), 0.14f)
            drawCircle(Brush.sweepGradient(listOf(Red, Blue, Cyan, Red), center), r - 2.dp.toPx(), style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
            drawCircle(Ink, r * 0.37f)
        }
        Box(
            Modifier.size(100.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(RedHot, Red, RedD)))
                .border(3.dp, Gold, CircleShape)
                .clickable { hf.performHapticFeedback(HapticFeedbackType.LongPress); vm.toggle() },
            contentAlignment = Alignment.Center
        ) { Glyph(if (vm.playing) Ic.PAUSE else Ic.PLAY, Snow, 42.dp) }

        val key = Modifier.size(62.dp).clip(CircleShape)
        Box(key.align(Alignment.CenterStart).clickable { vm.prev() }, Alignment.Center) { Glyph(Ic.PREV, Snow) }
        Box(key.align(Alignment.CenterEnd).clickable { vm.next() }, Alignment.Center) { Glyph(Ic.NEXT, Snow) }
        Box(key.align(Alignment.TopCenter).clickable { vm.skip(-10_000) }, Alignment.Center) {
            Text("-10s", color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Box(key.align(Alignment.BottomCenter).clickable { vm.skip(10_000) }, Alignment.Center) {
            Text("+10s", color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

// ================================================================= library tab

@Composable
fun LibraryTab(vm: Vm, onPickFolder: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("WEB-VERSE TRACK MATRIX [${vm.tracks.size} MODULES]", color = Snow, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(vm.status, color = Cyan, fontFamily = Mono, fontSize = 11.sp)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WebButton(if (vm.scanning) "SCANNING" else "SYNC", Cyan, Modifier.weight(1f)) { vm.rescan() }
                WebButton("+ FOLDER", Red, Modifier.weight(1f), true) { onPickFolder() }
                WebButton("FORGET", Dim, Modifier.weight(1f)) { vm.forget() }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WebButton(if (vm.scanDl) "DOWNLOADS: ON" else "DOWNLOADS: OFF", if (vm.scanDl) Gold else Dim, Modifier.weight(1f)) { vm.toggleDownloads() }
                WebButton(if (vm.scanMusic) "MUSIC: ON" else "MUSIC: OFF", if (vm.scanMusic) Gold else Dim, Modifier.weight(1f)) { vm.toggleMusic() }
            }
        }
        items(vm.folders) { f ->
            Row(
                Modifier.fillMaxWidth().clip(CutCornerShape(topEnd = 10.dp)).background(Panel.copy(alpha = 0.85f)).padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(treeLabel(f), color = Snow, fontFamily = Mono, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Box(Modifier.clickable { vm.removeFolder(f) }.padding(14.dp)) { Text("X", color = RedHot, fontFamily = Mono, fontWeight = FontWeight.Bold) }
            }
        }
        itemsIndexed(vm.tracks, key = { _, t -> t.uri.toString() }) { i, t ->
            val cur = !vm.onlineMode && i == vm.index
            val shape = CutCornerShape(topEnd = 12.dp, bottomStart = 12.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape)
                    .background(if (cur) Red.copy(alpha = 0.18f) else Panel.copy(alpha = 0.85f))
                    .border(1.dp, if (cur) Red else Panel2, shape)
                    .clickable { vm.play(i) }.padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (cur && vm.playing) ">>" else "%02d".format(i + 1), color = if (cur) RedHot else Dim, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(30.dp))
                Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                    Text(t.title, color = Snow, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.folder, color = Dim, fontFamily = Mono, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box(Modifier.clickable { vm.removeTrack(t) }.padding(14.dp)) { Text("X", color = Dim, fontFamily = Mono, fontWeight = FontWeight.Bold) }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
fun MiniBar(vm: Vm) {
    val t = vm.queue.getOrNull(vm.index) ?: return
    Row(
        Modifier.fillMaxWidth().background(Panel.copy(alpha = 0.95f)).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(t.title, color = Snow, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${mmss(vm.posMs)} / ${mmss(vm.durMs)}", color = Cyan, fontFamily = Mono, fontSize = 10.sp)
        }
        Box(Modifier.clip(CircleShape).clickable { vm.prev() }.padding(10.dp)) { Glyph(Ic.PREV, Snow, 22.dp) }
        Box(Modifier.clip(CircleShape).background(Red).clickable { vm.toggle() }.padding(10.dp)) { Glyph(if (vm.playing) Ic.PAUSE else Ic.PLAY, Snow, 24.dp) }
        Box(Modifier.clip(CircleShape).clickable { vm.next() }.padding(10.dp)) { Glyph(Ic.NEXT, Snow, 22.dp) }
    }
}

// ================================================================= online tab (Audius)

@Composable
fun OnlineTab(vm: Vm) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { if (vm.onlineResults.isEmpty()) vm.searchOnline(null) }
    val go = { vm.searchOnline(query) }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("ONLINE WEB-VERSE [AUDIUS]", color = Snow, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(vm.onlineStatus, color = Cyan, fontFamily = Mono, fontSize = 11.sp)
        }
        item {
            val shape = CutCornerShape(topEnd = 10.dp, bottomStart = 10.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clip(shape).background(Panel2.copy(alpha = 0.8f))
                        .border(1.5.dp, Cyan, shape).padding(horizontal = 12.dp, vertical = 11.dp)
                ) {
                    if (query.isEmpty()) Text("Search songs or artists", color = Dim, fontSize = 14.sp)
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = Snow, fontSize = 14.sp, fontFamily = Mono),
                        cursorBrush = SolidColor(RedHot),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { go() }),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                WebButton("SEARCH", Red, filled = true) { go() }
            }
        }
        item {
            WebButton("TRENDING", Gold, Modifier.fillMaxWidth()) { vm.searchOnline(null) }
        }
        itemsIndexed(vm.onlineResults, key = { i, t -> "$i-${t.name}" }) { i, t ->
            val cur = vm.onlineMode && i == vm.index
            val shape = CutCornerShape(topEnd = 12.dp, bottomStart = 12.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape)
                    .background(if (cur) Red.copy(alpha = 0.18f) else Panel.copy(alpha = 0.85f))
                    .border(1.dp, if (cur) Red else Panel2, shape)
                    .clickable { vm.playOnline(i) }.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (cur && vm.playing) ">>" else "%02d".format(i + 1), color = if (cur) RedHot else Dim,
                    fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(30.dp))
                Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                    Text(t.title, color = Snow, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.folder, color = Dim, fontFamily = Mono, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}
