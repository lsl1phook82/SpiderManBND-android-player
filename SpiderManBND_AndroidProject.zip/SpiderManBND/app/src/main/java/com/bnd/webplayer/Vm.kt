package com.bnd.webplayer

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class Vm(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    val player = Hub.player(app)

    var tracks by mutableStateOf(emptyList<Track>())
    /** The list currently loaded in the player (local library or online results). */
    var queue by mutableStateOf(emptyList<Track>())
    var onlineMode by mutableStateOf(false)
    var onlineResults by mutableStateOf(emptyList<Track>())
    var onlineStatus by mutableStateOf("SEARCH AUDIUS OR TAP TRENDING")
    var searching by mutableStateOf(false)
    var folders by mutableStateOf(prefs.folders.toList())
    var scanDl by mutableStateOf(prefs.scanDownloads)
    var scanMusic by mutableStateOf(prefs.scanMusic)
    var scanning by mutableStateOf(false)
    var status by mutableStateOf("TAP SYNC TO SCAN THE WEB-VERSE")

    var index by mutableIntStateOf(-1)
    var playing by mutableStateOf(false)
    var posMs by mutableStateOf(0L)
    var durMs by mutableStateOf(0L)
    var speed by mutableFloatStateOf(1f)
    var pitchLink by mutableStateOf(true)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_ALL)
    var shuffle by mutableStateOf(false)

    var burstTick by mutableIntStateOf(0)
    var burstWord by mutableStateOf("THWIP!")
    private val words = listOf("THWIP!", "THWACK!", "SPIDEY-SENSE!", "WEB-SLING!", "POW!", "SNAP!", "SWOOSH!", "NEW DAY!")

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            index = curIndex()
            if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) fx()
        }
        override fun onRepeatModeChanged(repeatMode: Int) { repeat = repeatMode }
        override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle = enabled }
    }

    init {
        player.repeatMode = repeat
        player.addListener(listener)
        playing = player.isPlaying
        index = curIndex()
        viewModelScope.launch {
            while (true) {
                delay(250)
                posMs = player.currentPosition
                durMs = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L
            }
        }
    }

    private fun curIndex() = if (player.mediaItemCount == 0) -1 else player.currentMediaItemIndex

    fun fx(word: String? = null) { burstWord = word ?: words.random(); burstTick++ }

    // ---------- library ----------
    fun rescan() {
        if (scanning) return
        scanning = true
        status = "SCANNING WEB-VERSE..."
        val app = getApplication<Application>()
        viewModelScope.launch {
            val list = try {
                withContext(Dispatchers.IO) { Library.scanAll(app, prefs) }
            } catch (_: Exception) { emptyList() }
            tracks = list
            if (!onlineMode) applyPlaylist()
            scanning = false
            status = if (list.isEmpty()) "NO TRACKS FOUND. ALLOW AUDIO ACCESS OR ADD A FOLDER."
            else "${list.size} TRACKS IN ${list.map { it.folder }.toSet().size} FOLDERS"
            fx("SYNCED!")
        }
    }

    private fun item(t: Track) = MediaItem.Builder()
        .setUri(t.uri)
        .setMediaId(t.uri.toString())
        .setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.folder).build())
        .build()

    private fun applyPlaylist() {
        if (onlineMode) return
        queue = tracks
        val items = tracks.map(::item)
        val same = player.mediaItemCount == items.size &&
            items.indices.all { player.getMediaItemAt(it).mediaId == items[it].mediaId }
        if (!same) {
            if (items.isEmpty()) {
                player.stop(); player.clearMediaItems()
            } else {
                val cur = player.currentMediaItem?.mediaId
                val at = items.indexOfFirst { it.mediaId == cur }
                val was = player.playWhenReady
                if (at >= 0) player.setMediaItems(items, at, player.currentPosition)
                else player.setMediaItems(items, 0, 0L)
                player.prepare()
                player.playWhenReady = at >= 0 && was
            }
        }
        index = curIndex()
    }

    fun addFolder(uri: Uri) {
        prefs.folders = prefs.folders + uri.toString()
        folders = prefs.folders.toList()
        rescan()
    }

    fun removeFolder(f: String) {
        prefs.folders = prefs.folders - f
        folders = prefs.folders.toList()
        try {
            getApplication<Application>().contentResolver.releasePersistableUriPermission(
                Uri.parse(f), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {}
        rescan()
    }

    fun removeTrack(t: Track) {
        prefs.excluded = prefs.excluded + t.uri.toString()
        tracks = tracks - t
        if (!onlineMode) applyPlaylist()
    }

    fun forget() {
        prefs.folders = emptySet(); prefs.excluded = emptySet()
        folders = emptyList()
        fx("FORGOTTEN!")
        rescan()
    }

    fun toggleDownloads() { prefs.scanDownloads = !prefs.scanDownloads; scanDl = prefs.scanDownloads; rescan() }
    fun toggleMusic() { prefs.scanMusic = !prefs.scanMusic; scanMusic = prefs.scanMusic; rescan() }

    // ---------- transport ----------
    fun play(i: Int) {
        if (i !in tracks.indices) return
        if (onlineMode) {
            onlineMode = false
            load(tracks, i)
        } else {
            player.seekTo(i, 0L)
            player.prepare()
            player.playWhenReady = true
        }
    }

    private fun load(list: List<Track>, start: Int) {
        queue = list
        player.setMediaItems(list.map(::item), start, 0L)
        player.prepare()
        player.playWhenReady = true
        index = curIndex()
    }

    fun playOnline(i: Int) {
        if (i !in onlineResults.indices) return
        onlineMode = true
        load(onlineResults, i)
    }

    fun searchOnline(q: String?) {
        if (searching) return
        searching = true
        onlineStatus = if (q.isNullOrBlank()) "LOADING TRENDING..." else "SEARCHING AUDIUS..."
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { if (q.isNullOrBlank()) Audius.trending() else Audius.search(q.trim()) }
                onlineResults = r
                onlineStatus = if (r.isEmpty()) "NOTHING FOUND. TRY ANOTHER SEARCH." else "${r.size} ONLINE TRACKS // POWERED BY AUDIUS"
            } catch (_: Exception) {
                onlineStatus = "OFFLINE OR AUDIUS IS BUSY. TRY AGAIN."
            }
            searching = false
        }
    }

    fun toggle() {
        if (player.mediaItemCount == 0) { fx("NO TRACKS!"); return }
        if (player.isPlaying) player.pause()
        else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0, 0L)
            player.prepare()
            player.play()
        }
        fx(if (player.playWhenReady) "THWIP!" else "FREEZE!")
    }

    fun next() {
        if (player.mediaItemCount == 0) return
        if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(0, 0L)
        player.playWhenReady = true
    }

    fun prev() {
        if (player.mediaItemCount == 0) return
        if (player.currentPosition > 3000L) player.seekTo(0L)
        else if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
        else player.seekTo(player.mediaItemCount - 1, 0L)
        player.playWhenReady = true
    }

    fun skip(ms: Long) {
        if (player.mediaItemCount == 0) return
        val end = if (durMs > 0) durMs else Long.MAX_VALUE
        player.seekTo((player.currentPosition + ms).coerceIn(0L, end))
        fx(if (ms > 0) "+10s!" else "-10s!")
    }

    fun seekFraction(f: Float) {
        if (durMs > 0) { player.seekTo((durMs * f).toLong()); posMs = (durMs * f).toLong() }
    }

    fun changeSpeed(v: Float) {
        speed = ((v.coerceIn(0.5f, 2f)) * 20f).roundToInt() / 20f
        applyParams()
    }

    fun togglePitchLink() { pitchLink = !pitchLink; applyParams(); fx("PITCH " + if (pitchLink) "LINKED!" else "FREE!") }

    private fun applyParams() { player.playbackParameters = PlaybackParameters(speed, if (pitchLink) speed else 1f) }

    fun cycleRepeat() { player.repeatMode = (player.repeatMode + 1) % 3; fx() }
    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled; fx("SHUFFLE!") }

    override fun onCleared() { player.removeListener(listener) }
}
