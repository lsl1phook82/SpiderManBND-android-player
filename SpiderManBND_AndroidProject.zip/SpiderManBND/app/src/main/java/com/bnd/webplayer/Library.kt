package com.bnd.webplayer

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.media.MediaScannerConnection
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

data class Track(
    val uri: Uri,
    val title: String,
    val folder: String,
    val name: String,
    val size: Long
)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("bnd_web_player", Context.MODE_PRIVATE)

    var scanDownloads: Boolean
        get() = sp.getBoolean("dl", true)
        set(v) { sp.edit().putBoolean("dl", v).apply() }

    var scanMusic: Boolean
        get() = sp.getBoolean("music", true)
        set(v) { sp.edit().putBoolean("music", v).apply() }

    /** Folders picked with the system folder picker (tree URIs), remembered between launches. */
    var folders: Set<String>
        get() = sp.getStringSet("folders", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("folders", v).apply() }

    /** Tracks the user removed; automatic scans skip them. */
    var excluded: Set<String>
        get() = sp.getStringSet("excluded", emptySet())!!.toSet()
        set(v) { sp.edit().putStringSet("excluded", v).apply() }
}

private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "wav", "ogg", "opus", "flac")
private const val MAX_FILES = 20000
private const val MAX_DEPTH = 12

fun treeLabel(tree: String): String = try {
    DocumentsContract.getTreeDocumentId(Uri.parse(tree)).substringAfter(':').ifEmpty { "Storage root" }
} catch (_: Exception) { tree }

fun naturalCompare(a: String, b: String): Int {
    val rx = Regex("\\d+|\\D+")
    val x = rx.findAll(a.lowercase()).map { it.value }.toList()
    val y = rx.findAll(b.lowercase()).map { it.value }.toList()
    for (i in 0 until minOf(x.size, y.size)) {
        val p = x[i]; val q = y[i]
        val c = if (p[0].isDigit() && q[0].isDigit()) {
            val pn = p.trimStart('0'); val qn = q.trimStart('0')
            if (pn.length != qn.length) pn.length - qn.length else pn.compareTo(qn)
        } else p.compareTo(q)
        if (c != 0) return c
    }
    return x.size - y.size
}

object Library {

    /** Downloads + Music (any depth, any folder names) via MediaStore, plus every picked folder tree. */
    fun scanAll(ctx: Context, prefs: Prefs): List<Track> {
        val out = ArrayList<Track>()
        if (prefs.scanDownloads) {
            indexNewFiles(ctx, Environment.DIRECTORY_DOWNLOADS)
            out += queryMedia(ctx, "Download/")
        }
        if (prefs.scanMusic) {
            indexNewFiles(ctx, Environment.DIRECTORY_MUSIC)
            out += queryMedia(ctx, "Music/")
        }
        for (f in prefs.folders) {
            try { walkTree(ctx, Uri.parse(f), out) } catch (_: Exception) {}
        }
        val excluded = prefs.excluded
        val seen = HashSet<String>()
        return out
            .filter { it.uri.toString() !in excluded && seen.add(it.name.lowercase() + "|" + it.size) }
            .sortedWith { a, b ->
                val c = naturalCompare(a.folder, b.folder)
                if (c != 0) c else naturalCompare(a.name, b.name)
            }
            .take(MAX_FILES)
    }

    /** MediaStore only lists files it has indexed. Ask it to index audio that was copied in by hand. */
    private fun indexNewFiles(ctx: Context, dir: String) {
        try {
            val root = Environment.getExternalStoragePublicDirectory(dir)
            val paths = ArrayList<String>()
            fun walk(d: File, depth: Int) {
                if (depth > MAX_DEPTH || paths.size > MAX_FILES) return
                val kids = d.listFiles() ?: return
                for (k in kids) {
                    if (k.name.startsWith(".")) continue
                    if (k.isDirectory) walk(k, depth + 1)
                    else if (k.extension.lowercase() in AUDIO_EXT) paths += k.absolutePath
                }
            }
            walk(root, 0)
            if (paths.isEmpty()) return
            val latch = CountDownLatch(paths.size)
            MediaScannerConnection.scanFile(ctx, paths.toTypedArray(), null) { _, _ -> latch.countDown() }
            latch.await(5, TimeUnit.SECONDS)
        } catch (_: Exception) {}
    }

    private fun queryMedia(ctx: Context, relPrefix: String): List<Track> {
        val out = ArrayList<Track>()
        val base = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.RELATIVE_PATH,
            MediaStore.Audio.Media.SIZE
        )
        try {
            ctx.contentResolver.query(
                base, proj,
                "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?",
                arrayOf("$relPrefix%"), null
            )?.use { c ->
                while (c.moveToNext() && out.size < MAX_FILES) {
                    val name = c.getString(1) ?: continue
                    if (name.startsWith(".")) continue
                    val rel = (c.getString(2) ?: relPrefix).trimEnd('/')
                    val uri = Uri.withAppendedPath(base, c.getLong(0).toString())
                    out += Track(uri, name.substringBeforeLast('.'), rel, name, c.getLong(3))
                }
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {}
        return out
    }

    private fun walkTree(ctx: Context, tree: Uri, out: MutableList<Track>) {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        fun walk(docId: String, path: String, depth: Int) {
            if (depth > MAX_DEPTH || out.size > MAX_FILES) return
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val dirs = ArrayList<Pair<String, String>>()
            try {
                ctx.contentResolver.query(kids, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2) ?: ""
                        if (name.startsWith(".")) continue
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            dirs += id to name
                        } else if (mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in AUDIO_EXT) {
                            out += Track(
                                DocumentsContract.buildDocumentUriUsingTree(tree, id),
                                name.substringBeforeLast('.'), path, name, c.getLong(3)
                            )
                        }
                    }
                }
            } catch (_: Exception) {}
            for ((id, n) in dirs) walk(id, "$path/$n", depth + 1)
        }
        walk(rootId, treeLabel(tree.toString()), 0)
    }
}
